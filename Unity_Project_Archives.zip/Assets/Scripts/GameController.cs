﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public UserData userData;
    public UserData userDataJsonFile;
    public Users usersList;
    public GameObject loginPage, registerPage, LoggedPage;
    public GameObject okName, okPassword, nameDoesNotExist, passwordIncorrect, usernameAlreadyExist;
    public InputField loginName, loginPassword;
    public InputField userName, userEmail, userPassword, userBirthday;
    private string serverLocalPath;
    private string gameDataFile = "/Resources";

    private void Awake()
    {
        DontDestroyOnLoad(this.gameObject);

        loginPage.SetActive(true);
        registerPage.SetActive(false);
        LoggedPage.SetActive(false);
        okName.SetActive(false);
        okPassword.SetActive(false);
        nameDoesNotExist.SetActive(false);
        passwordIncorrect.SetActive(false);
        usernameAlreadyExist.SetActive(false);

        serverLocalPath = Application.dataPath + gameDataFile;
    }

    private void Start()
    {
        LocalizeAllFiles();

        //Teste para encontrar files específicos.
        if(File.Exists(serverLocalPath + "/Henrique.json"))
        {
            Debug.Log("Arquivo encontrado");

            string saveString = File.ReadAllText(serverLocalPath + "/Henrique.json");

            UserData userFile = JsonUtility.FromJson<UserData>(saveString);
        }
        else
        {
            Debug.Log("Arquivo não encontrado");
        }

        Debug.Log(serverLocalPath);

        if(loginPage && registerPage)
        {
            loginPage.SetActive(true);
            registerPage.SetActive(false);
        }
        else
        {
            Debug.LogError("Pages Not Found...");
        }
    }

    #region Functions

    public void RegisterAccount()
    {
        userData.Name = userName.text;
        userData.Email = userEmail.text;
        userData.Password = userPassword.text;
        userData.Birthday = userBirthday.text;

        string fileName = userData.Name;
        string toJsonFile = JsonUtility.ToJson(userData);

        userDataJsonFile = JsonUtility.FromJson<UserData>(toJsonFile);

        Debug.Log(userDataJsonFile);

        CreateNewUserDataFile(fileName, userData);
    }

    public void CreateNewUserDataFile(string jsonFileName, UserData jsonScript)
    {
        if(File.Exists(serverLocalPath + "/" + jsonFileName + ".json"))
        {
            usernameAlreadyExist.SetActive(true);
            Debug.Log("Arquivo de nome: '" + jsonFileName + "' já existe.");
        }
        else
        {
            string json = JsonUtility.ToJson(jsonScript);

            if(File.Exists(serverLocalPath + "/" + jsonFileName + ".json"))
            {
                File.Delete(serverLocalPath + "/" + jsonFileName + ".json");
            }

            File.WriteAllText(serverLocalPath + "/" + jsonFileName + ".json", json);

            usernameAlreadyExist.SetActive(false);

            Debug.Log("Arquivo: " + jsonFileName + " criado com sucesso.");
        }
    }

    public void LoginButton()
    {
        if(loginName.text != userDataJsonFile.Name && loginPassword.text != userDataJsonFile.Password)
        {
            nameDoesNotExist.SetActive(true);
            passwordIncorrect.SetActive(true);
            okName.SetActive(false);
            okPassword.SetActive(false);
        }

        if(loginName.text == userDataJsonFile.Name && loginPassword.text == userDataJsonFile.Password)
        {
            StartCoroutine(TimeToLogIn());
        }

        if(loginName.text == userDataJsonFile.Name && loginPassword.text != userDataJsonFile.Password)
        {
            okName.SetActive(true);
            passwordIncorrect.SetActive(true);
            nameDoesNotExist.SetActive(false);
            okPassword.SetActive(false);
        }
    }

    public void RegisterButton()
    {
        // Open Register System...

        registerPage.SetActive(true);
        loginPage.SetActive(false);
    }

    public void DoneButton()
    {
        // Back to the Login Page...

        loginPage.SetActive(true);
        registerPage.SetActive(false);
    }

    public void ExitButton()
    {
        loginPage.SetActive(true);
        registerPage.SetActive(false);
        LoggedPage.SetActive(false);
        okName.SetActive(false);
        okPassword.SetActive(false);
        nameDoesNotExist.SetActive(false);
        passwordIncorrect.SetActive(false);
    }

    private IEnumerator TimeToLogIn()
    {
        okName.SetActive(true);
        okPassword.SetActive(true);
        nameDoesNotExist.SetActive(false);
        passwordIncorrect.SetActive(false);
        
        yield return new WaitForSeconds(2f);

        LoggedPage.SetActive(true);
        loginPage.SetActive(false);
        registerPage.SetActive(false);
        okName.SetActive(false);
        okPassword.SetActive(false);
        nameDoesNotExist.SetActive(false);
        passwordIncorrect.SetActive(false);
    }

    #endregion

    #region Json Server

    public UserData[] userServer;
    public string[] jsonFileName;
    public List<Text> jsonText = new List<Text>();

    public void CreateAccount()
    {
        for(int i = 0; i < userServer.Length; i++)
        {
            if(userServer[i].Name == "" && userServer[i].Email == "" && userServer[i].Password == "" && userServer[i].Birthday == "")
            {
                userServer[i].Name = userName.text;
                userServer[i].Email = userEmail.text;
                userServer[i].Password = userPassword.text;
                userServer[i].Birthday = userBirthday.text;

                string fileName = userServer[i].Name;
                string toJsonFile = JsonUtility.ToJson(userServer[i]);

                Debug.Log(toJsonFile);

                CreateNewUserDataFile(fileName, userServer[i]);

                return;
            }
        }
    }

    public void LocalizeAllFiles()
    {
        // Carregar todos dado Json que estão na pasta Resources.

        if(!Directory.Exists(serverLocalPath))
        {
            Debug.Log("Pasta não encontrada");
        }
        else
        {
            Debug.Log("Pasta encontrada");
        }
    }

    #endregion
}