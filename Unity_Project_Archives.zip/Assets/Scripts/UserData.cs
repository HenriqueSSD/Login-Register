﻿using System.Collections.Generic;

[System.Serializable]
public class UserData
{ 
    public static UserData instance;

    void Awake()
    {
        instance = this;
    }

    public string Name;
    public string Email;
    public string Password;
    public string Birthday;
}

// Faltou essa joça...
[System.Serializable]
public class Users
{
     public List<UserData> userDataList = new List<UserData>();
}
